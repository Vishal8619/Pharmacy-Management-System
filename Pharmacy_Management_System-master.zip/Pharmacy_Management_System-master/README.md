# Pharmacy_management_system
A Pharmacy management system with Gui and a database connectivity in python using Tkinter.The user can add,update,delete and search medicinal details.

